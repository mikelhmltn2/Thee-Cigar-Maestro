// JS for loading pairing data
fetch('../data/pairing.json').then(r => r.json()).then(console.log);