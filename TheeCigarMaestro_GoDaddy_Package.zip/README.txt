This package includes the website structure and branding information for Thee Cigar Maestro GoDaddy site.
Files:
- website-structure.json
- branding-guide.txt
- Cigarmaestro.json (original)
- README.txt